"""Fast correctness checks for the implemented attacks and update objectives."""
import os
os.environ["CS521_DEVICE"] = "cpu"
import unittest
import torch
import torch.nn as nn
import q3_multinorm as q

class Q3Tests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(2)
        torch.manual_seed(17)
        self.model = nn.Sequential(nn.Flatten(), nn.Linear(3*4*4, 5))
        self.x = torch.rand(4,3,4,4)
        self.y = torch.tensor([0,1,2,3])
    def test_linf_bounds_and_mode(self):
        self.model.train()
        adv = q.pgd_linf(self.model,self.x,self.y,0.1,0.04,3)
        self.assertTrue(self.model.training)
        self.assertLessEqual((adv-self.x).abs().max().item(),0.100001)
        self.assertTrue(bool((adv>=0).all() and (adv<=1).all()))
        self.assertFalse(adv.requires_grad)
    def test_l2_bounds(self):
        adv = q.pgd_l2(self.model,self.x,self.y,0.4,0.2,3)
        self.assertLessEqual((adv-self.x).flatten(1).norm(dim=1).max().item(),0.400001)
        self.assertTrue(bool((adv>=0).all() and (adv<=1).all()))
    def test_zero_radius(self):
        for attack in [q.pgd_linf,q.pgd_l2]:
            self.assertTrue(torch.equal(attack(self.model,self.x,self.y,0.,0.,2),self.x))
    def test_gradient_projection(self):
        gn=torch.tensor([2.,0.]);ga=torch.tensor([1.,1.])
        self.assertTrue(torch.allclose(q.gradient_projection(gn,ga),torch.tensor([2**.5,0.])))
        self.assertTrue(torch.equal(q.gradient_projection(gn,-gn),torch.zeros_like(gn)))
        self.assertTrue(torch.equal(q.gradient_projection(torch.zeros_like(gn),ga),torch.zeros_like(gn)))
    def test_ramp_loss_and_gradients(self):
        loss=q.ramp_loss(self.model,self.x,self.y)
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in self.model.parameters()))
    def test_own_loss_teacher_frozen_and_alternation(self):
        teacher=nn.Sequential(nn.Flatten(),nn.Linear(3*4*4,5))
        loss_fn=q.AlternatingDistillationLoss(teacher)
        for _ in range(2):
            loss=loss_fn(self.model,self.x,self.y)
            loss.backward()
            self.assertTrue(torch.isfinite(loss))
        self.assertEqual([r["norm"] for r in loss_fn.stats],["l1","l2"])
        self.assertTrue(all(p.grad is None for p in teacher.parameters()))

if __name__=="__main__": unittest.main(verbosity=2)
