"""Q1 reconstructed experiment using the public HW1 architecture.

The original Q1 training notebook / HW1 checkpoints were unavailable.
This explicitly documented protocol is an independent reconstruction, not a
claim that the missing starter's hyperparameters have been recovered.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

import q3_multinorm as helper
from hw1_model import PreActResNet18

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / "results/q1"
device = helper.device

def new_model():
    return PreActResNet18(10, cuda=device.type == "cuda",
                         activation="softplus1", normal="none").to(device)

def train(model, eps, epochs, lr, seed=0):
    torch.manual_seed(seed)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=.9, weight_decay=5e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, epochs * (len(helper.x_train) // 128))
    history = []
    for epoch in range(epochs):
        helper.sync_device()
        before = time.perf_counter()
        losses = []
        for x, y in helper.batches(helper.x_train, helper.y_train, 128, True):
            if len(y) < 128:
                continue
            x = helper.augment(x)
            if eps:
                model.eval()
                x = helper.pgd_linf(model, x, y, eps, 2.5 * eps / 10, 10, True)
            model.train()
            loss = F.cross_entropy(model(x), y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            sched.step()
            losses.append(loss.item())
        helper.sync_device()
        history.append({"epoch":epoch+1, "mean_loss":float(np.mean(losses)),
                        "seconds":time.perf_counter()-before})
        print("Q1_TRAIN", eps, json.dumps(history[-1]), flush=True)
    return history

def evaluate(model):
    model.eval()
    rows = []
    for units in [0, 2, 4, 8, 12]:
        eps = units / 255
        torch.manual_seed(42)
        counts = {"clean":0,"fgsm":0,"pgd":0}
        helper.sync_device()
        before = time.perf_counter()
        for x, y in helper.batches(helper.x_test, helper.y_test, 125, False):
            with torch.no_grad():
                correct = model(x).argmax(1) == y
            counts["clean"] += correct.sum().item()
            if units == 0:
                counts["fgsm"] += correct.sum().item()
                counts["pgd"] += correct.sum().item()
                continue
            fgsm = helper.pgd_linf(model, x, y, eps, eps, 1, False)
            with torch.no_grad():
                counts["fgsm"] += (correct & (model(fgsm).argmax(1) == y)).sum().item()
            robust = correct.clone()
            for _ in range(2):
                adv = helper.pgd_linf(model, x, y, eps, eps / 4, 50, True)
                with torch.no_grad():
                    robust &= model(adv).argmax(1) == y
            counts["pgd"] += robust.sum().item()
        helper.sync_device()
        row = {"test_eps_over_255":units,
               "accuracy_percent":{k:100*v/len(helper.y_test) for k,v in counts.items()},
               "seconds":time.perf_counter()-before}
        rows.append(row)
        print("Q1_EVALUATE",json.dumps(row),flush=True)
    return rows

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode",choices=["all","clean","adv"],default="all")
    p.add_argument("--eps",type=int,default=4)
    args = p.parse_args()
    torch.set_num_threads(4)
    helper.initialize_data()
    DEST.mkdir(parents=True,exist_ok=True)
    protocol = {
        "status":"Reconstructed protocol; missing original Q1 training starter",
        "architecture":"Public HW1 PreActResNet18, width 64, softplus1, no input normalization",
        "train":"Official Q3 balanced 10000-image CIFAR-10 training subset",
        "test":"Official Q3 first 1000 CIFAR-10 test images; no training on test",
        "clean_epochs":20,"clean_lr":.05,"adversarial_epochs":10,"adversarial_lr":.01,
        "training_eps_over_255":[2,4,8],"batch_size":128,"seed":0,
        "optimizer":"SGD(momentum=.9,weight_decay=.0005), cosine LR",
        "augmentation":"random horizontal flip and random crop, padding 4",
        "pgd_train":{"steps":10,"alpha":"2.5*eps/10","random_start":True},
        "pgd_eval":{"steps":50,"restarts":2,"alpha":"eps/4","random_start":True},
        "fgsm_eval":{"steps":1,"alpha":"eps","random_start":False},
        "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (DEST/"protocol.json").write_text(json.dumps(protocol,indent=2))
    original = DEST/"original_clean"
    original.mkdir(exist_ok=True)
    if args.mode in ["all","clean"] and not (original/"result.json").exists():
        torch.manual_seed(0)
        model = new_model()
        if not (original/"model.pt").exists():
            history = train(model, 0, 20, .05)
            helper.save_model(model, original/"model.pt")
            (original/"training_history.json").write_text(json.dumps(history,indent=2))
        else:
            model.load_state_dict(torch.load(original/"model.pt",weights_only=True,map_location=device))
        results = evaluate(model)
        (original/"result.json").write_text(json.dumps(results,indent=2))
        del model
    eps_values = [2,4,8] if args.mode == "all" else [args.eps] if args.mode == "adv" else []
    for units in eps_values:
        dest = DEST/f"pgd_train_eps{units}_over255"
        dest.mkdir(exist_ok=True)
        if (dest/"result.json").exists():
            continue
        model = new_model()
        if not (dest/"model.pt").exists():
            model.load_state_dict(torch.load(original/"model.pt",weights_only=True,map_location=device))
            history = train(model, units/255, 10, .01)
            helper.save_model(model,dest/"model.pt")
            (dest/"training_history.json").write_text(json.dumps(history,indent=2))
        else:
            model.load_state_dict(torch.load(dest/"model.pt",weights_only=True,map_location=device))
        results = evaluate(model)
        (dest/"result.json").write_text(json.dumps(results,indent=2))
        del model
    print("Q1_COMPLETE",flush=True)

if __name__ == "__main__":
    main()
