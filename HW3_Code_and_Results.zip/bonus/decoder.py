"""CRANE-style switching decoder."""
import hashlib
import json
from pathlib import Path
import re

RECORD_PATTERN = (
    r"[a-zA-Z_][a-zA-Z_0-9]*\(op=(add|sub|mul|div|and|or|xor|not|copy),"
    r"inputs=\[(q[0-9]+|s[0-9]+)(,(q[0-9]+|s[0-9]+))*\]\)"
    r"->(-?[0-9]+(\.[0-9]+)?|True|False)>>"
)
RECORD_RE = re.compile(
    r"<<(?P<name>[a-zA-Z_][a-zA-Z_0-9]*)\(op=(?P<op>add|sub|mul|div|and|or|xor|not|copy),"
    r"inputs=\[(?P<inputs>(?:q[0-9]+|s[0-9]+)(?:,(?:q[0-9]+|s[0-9]+))*)\]\)"
    r"->(?P<output>-?[0-9]+(?:\.[0-9]+)?|True|False)>>"
)

GRAMMAR = r"""
start: NAME "(op=" OP ",inputs=[" REF ("," REF)* "])->" VALUE ">>"
NAME: /[a-zA-Z_][a-zA-Z_0-9]*/
OP: "add" | "sub" | "mul" | "div" | "and" | "or" | "xor" | "not" | "copy"
REF: /[qs][0-9]+/
VALUE: /-?[0-9]+(\.[0-9]+)?/ | "True" | "False"
"""


def value(s):
    if s in ("True", "False"):
        return s == "True"
    return float(s)


def parse_steps(text):
    matches = list(RECORD_RE.finditer(text))
    records = []
    for i, m in enumerate(matches):
        records.append(dict(index=i, name=m["name"], op=m["op"],
                            refs=m["inputs"].split(","), output=value(m["output"]),
                            span=list(m.span()), output_span=list(m.span("output"))))
    valid = bool(records) and text.count("<<") == len(records) == text.count(">>")
    return records, valid


class SwitchingAutomaton:
    """A character DFA with two free-text states and a record subautomaton.

    State 0 is free text; state 1 remembers a trailing '<'. Completing '<<'
    activates the record DFA. Completing '>>' returns to free text. Entire token
    strings are checked, including tokens crossing delimiter boundaries.
    """
    def __init__(self):
        from interegular import parse_pattern
        self.dfa = parse_pattern(RECORD_PATTERN).to_fsm().reduce()
        self.states = sorted(self.dfa.states - self.dfa.finals)
        self.to_index = {s: i + 2 for i, s in enumerate(self.states)}
        self.from_index = {i: s for s, i in self.to_index.items()}
        self.initial = self.to_index[self.dfa.initial]
        self.n = len(self.states) + 2
        self.char_cache = {}

    def step_char(self, state, char):
        key = state, char
        if key in self.char_cache:
            return self.char_cache[key]
        if state == 0:
            result = 1 if char == "<" else 0
        elif state == 1:
            result = self.initial if char == "<" else 0
        else:
            current = self.from_index[state]
            try:
                symbol = self.dfa.alphabet[char]
            except KeyError:
                result = -1
            else:
                target = self.dfa.map[current].get(symbol)
                result = (-1 if target is None else
                          0 if target in self.dfa.finals else self.to_index[target])
        self.char_cache[key] = result
        return result

    def walk(self, state, text):
        for char in text:
            state = self.step_char(state, char)
            if state < 0:
                break
        return state

    def token_table(self, tokenizer, vocab_size, cache_dir):
        import numpy as np
        # This decoder is intended for byte-level BPE tokenizers such as Qwen2.5.
        # ASCII token decoding is exact; non-ASCII is accepted in free text only.
        valid_vocab_size = len(tokenizer)
        pieces = [tokenizer.decode([i], skip_special_tokens=False,
                                   clean_up_tokenization_spaces=False)
                  if i < valid_vocab_size else ""
                  for i in range(vocab_size)]
        signature = hashlib.sha256((RECORD_PATTERN + json.dumps(pieces)).encode()).hexdigest()
        path = Path(cache_dir) / ("transition_" + signature[:16] + ".npy")
        if path.exists():
            return np.load(path), signature
        # Prefix sharing avoids walking identical prefixes for each vocabulary item.
        trie = {}
        for token_id, piece in enumerate(pieces):
            node = trie
            for char in piece:
                node = node.setdefault(char, {})
            node.setdefault(None, []).append(token_id)
        table = np.full((self.n, vocab_size), -1, dtype=np.int16)
        specials = set(tokenizer.all_special_ids)
        eos = tokenizer.eos_token_id
        for initial in range(self.n):
            stack = [(trie, initial)]
            while stack:
                node, state = stack.pop()
                for char, child in node.items():
                    if char is None:
                        table[initial, child] = state
                    else:
                        target = self.step_char(state, char)
                        if target >= 0:
                            stack.append((child, target))
            for token_id in specials:
                if token_id < vocab_size:
                    table[initial, token_id] = -1
            table[initial, valid_vocab_size:] = -1
            if initial < 2:
                table[initial, eos] = initial
        # Every reachable state must offer at least one valid continuation.
        if not (table >= 0).any(axis=1).all():
            raise RuntimeError("The grammar has a tokenization dead end.")
        path.parent.mkdir(parents=True, exist_ok=True)
        np.save(path, table)
        return table, signature


class SwitchingLogitsProcessor:
    def __init__(self, transitions, initial_states, prompt_width):
        import torch
        self.transitions = transitions
        self.states = torch.tensor(initial_states, device=transitions.device, dtype=torch.long)
        self.width = prompt_width
        self.processed = prompt_width
        self.active_counts = 0
        self.calls = 0

    def __call__(self, input_ids, scores):
        import torch
        # Transformers calls this once before sampling every next token.
        while self.processed < input_ids.shape[1]:
            chosen = input_ids[:, self.processed]
            self.states = self.transitions[self.states, chosen].long()
            if (self.states < 0).any():
                raise RuntimeError("A generated token violated the switching grammar.")
            self.processed += 1
        allowed = self.transitions[self.states] >= 0
        if allowed.shape[1] != scores.shape[1]:
            raise RuntimeError("Tokenizer/model vocabulary mismatch.")
        self.calls += 1
        return scores.masked_fill(~allowed, -torch.inf)


def self_test():
    machine = SwitchingAutomaton()
    good = "Reason freely: <<multiply_boxes(op=mul,inputs=[q0,q1])->60>>\nANSWER: 60"
    assert machine.walk(0, good) == 0
    assert machine.walk(0, "Unstructured words and 中文 remain free.") == 0
    assert machine.walk(0, "<<bad name(") == -1
    assert machine.walk(0, "<<name(op=add,inputs=[q0,s0])->-1.25>>x") == 0
    assert machine.walk(0, "<<logical(op=not,inputs=[q0])->False>>") == 0
    assert machine.walk(0, "<<name(op=add,inputs=[])->1>>") == -1
    records, ok = parse_steps(good)
    assert ok and records[0]["output"] == 60
    return {"states": machine.n, "tests": 6}


if __name__ == "__main__":
    print(json.dumps(self_test()))
