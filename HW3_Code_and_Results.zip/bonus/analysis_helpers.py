"""Recompute every metric from saved raw predictions; never impute missing runs."""
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path
import re

import numpy as np
from scipy.stats import beta, fisher_exact
from decoder import parse_steps
from experiments import read_rows, same

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"


def structured_audit(row):
    records, parse_ok = parse_steps(row["text"])
    if not parse_ok:
        return {"pass": False, "issues": ["parse_failure"], "provenance_pass": False,
                "computation_pass": False, "answer_link_pass": False}
    previous = []
    provenance, computation = True, True
    issues = []
    for step in records:
        values = []
        for ref in step["refs"]:
            source = row["atoms"] if ref[0] == "q" else previous
            index = int(ref[1:])
            if index >= len(source):
                provenance = False
                issues.append(f"step{step['index']}:undefined_{ref}")
                values.append(None)
            else:
                values.append(source[index])
        expected = None
        try:
            op = step["op"]
            if any(v is None for v in values):
                raise ValueError("undefined")
            if op in ("not", "copy"):
                if len(values) != 1:
                    raise ValueError("unary arity")
                if op == "not":
                    if type(values[0]) is not bool:
                        raise ValueError("boolean type")
                    expected = not values[0]
                else:
                    expected = values[0]
            else:
                if len(values) != 2:
                    raise ValueError("binary arity")
                a, b = values
                if op in ("and", "or", "xor"):
                    if type(a) is not bool or type(b) is not bool:
                        raise ValueError("boolean type")
                    expected = {"and": lambda: a and b, "or": lambda: a or b,
                                "xor": lambda: a != b}[op]()
                else:
                    if isinstance(a, bool) or isinstance(b, bool):
                        raise ValueError("numeric type")
                    expected = {"add": lambda: a+b, "sub": lambda: a-b,
                                "mul": lambda: a*b, "div": lambda: a/b}[op]()
        except (ValueError, ZeroDivisionError, OverflowError):
            computation = False
            issues.append(f"step{step['index']}:cannot_compute")
        if expected is not None and not same(expected, step["output"]):
            computation = False
            issues.append(f"step{step['index']}:wrong_output")
        previous.append(step["output"])
    linked = same(previous[-1], row["predicted"])
    if not linked:
        issues.append("final_answer_disagrees_with_last_record")
    return {"pass": provenance and computation and linked, "issues": issues,
            "provenance_pass": provenance, "computation_pass": computation,
            "answer_link_pass": linked}


NAME_CLASSES = [
    ("EXTRACT", r"get|extract|data|initial|given|input"),
    ("FINISH", r"final|answer|result"),
    ("NEGATE", r"not|negat|invert"),
    ("MULTIPLY", r"mult|product|times|scale"),
    ("DIVIDE", r"div|ratio|per_|average|each"),
    ("SUBTRACT", r"sub|minus|remain|left|diff|change"),
    ("ADD", r"add|sum|total|combine"),
    ("LOGIC", r"and|or_|xor|truth|bool|logic|evaluate"),
    ("COMPUTE", r"comput|calcul|step|eval")
]
CLASSES = [x[0] for x in NAME_CLASSES] + ["OTHER", "<END>"]


def name_class(name):
    name = re.sub(r"\d+", "", name.lower())
    for label, pattern in NAME_CLASSES:
        if re.search(pattern, name):
            return label
    return "OTHER"


class Typicality:
    def __init__(self, rows):
        self.counts = defaultdict(Counter)
        self.total = Counter()
        for row in rows:
            seq = ["<START>"] + [name_class(s["name"]) for s in row["steps"]] + ["<END>"]
            for left, right in zip(seq, seq[1:]):
                self.counts[left][right] += 1
                self.total[left] += 1

    def score(self, row):
        seq = ["<START>"] + [name_class(s["name"]) for s in row["steps"]] + ["<END>"]
        logs = [math.log((self.counts[a][b]+1)/(self.total[a]+len(CLASSES)))
                for a, b in zip(seq, seq[1:])]
        return -sum(logs)/len(logs)


def audit_stats(rows, key):
    passed = [r for r in rows if r[key]]
    failed = [r for r in rows if not r[key]]
    pc = sum(r["correct"] for r in passed)
    fc = sum(r["correct"] for r in failed)
    table = [[pc, len(passed)-pc], [fc, len(failed)-fc]]
    odds, p = fisher_exact(table, alternative="two-sided")
    return dict(n=len(rows), failed=len(failed), fail_pct=100*len(failed)/len(rows),
                pass_accuracy=None if not passed else 100*pc/len(passed),
                fail_accuracy=None if not failed else 100*fc/len(failed),
                contingency=table, fisher_p=float(p),
                odds_ratio=float(odds) if np.isfinite(odds) else None)


def cp(k, n, delta=.05):
    return [0.0 if k == 0 else float(beta.ppf(delta/2, k, n-k+1)),
            1.0 if k == n else float(beta.ppf(1-delta/2, k+1, n-k))]


def relaxed_json(text):
    """Post-hoc diagnostic only: remove one complete Markdown code fence."""
    text = text.strip()
    match = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", text, re.S)
    if match:
        text = match[1]
    def unique_keys(pairs):
        result = {}
        for key, val in pairs:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = val
        return result
    try:
        obj = json.loads(text, object_pairs_hook=unique_keys)
        if type(obj) is dict and all(type(v) is int for v in obj.values()):
            return obj
    except (ValueError, TypeError):
        pass
    return None


def analyze():
    rows = read_rows(RESULTS / "faithfulness.jsonl")
    summary = {"complete": False, "accuracy": [], "audits": [], "interventions": [],
               "ledger": [], "limitations": [
                   "Recorded experimental results.",
                   "One small model and one generation seed; no claim about all LLMs.",
                   "Fixed-template condition is prompt-only, not a trained SSRM reproduction.",
                   "Greedy completions can vary slightly with batch padding and GPU arithmetic.",
                   "Arithmetic/provenance consistency and intervention sensitivity do not prove faithfulness.",
                   "Pretrained benchmark contamination is unknown.",
                   "The deliberately narrow operation/reference language can hurt correctness.",
                   "The type of experiment differs between GSM8K numeric and BBH Boolean reasoning."
               ]}
    for task in ("gsm8k", "bbh_boolean"):
        for condition in ("cot", "fixed", "crane"):
            selected = [r for r in rows if r["task"] == task and
                        r["condition"] == condition and r["split"] == "test"]
            if not selected:
                continue
            summary["accuracy"].append(dict(task=task, condition=condition, n=len(selected),
                correct=sum(r["correct"] for r in selected),
                accuracy=100*sum(r["correct"] for r in selected)/len(selected),
                parse_pct=100*sum(r["parse_ok"] for r in selected)/len(selected),
                truncated=sum(r["truncated"] for r in selected),
                mean_tokens=float(np.mean([r["generated_tokens"] for r in selected]))))
    audit_rows = []
    typical_metadata = {}
    for task in ("gsm8k", "bbh_boolean"):
        dev = [r for r in rows if r["task"] == task and r["condition"] == "crane" and
               r["split"] == "dev" and r["parse_ok"]]
        # Split by original frozen order; no test labels used to select the threshold.
        fit, calibration = dev[:25], dev[25:]
        model = Typicality(fit)
        threshold = None if not calibration else float(np.quantile(
            [model.score(r) for r in calibration], .95, method="higher"))
        typical_metadata[task] = dict(fit_n=len(fit), calibration_n=len(calibration),
                                      threshold=threshold, normalization=NAME_CLASSES,
                                      counts={k: dict(v) for k, v in model.counts.items()},
                                      smoothing=1, length_normalized=True)
        for row in [r for r in rows if r["task"] == task and r["split"] == "test"
                    and r["condition"] == "crane"]:
            audit = structured_audit(row)
            score = model.score(row)
            item = dict(id=row["id"], task=task, correct=row["correct"], audit=audit,
                        structured_pass=audit["pass"],
                        provenance_pass=audit["provenance_pass"],
                        computation_pass=audit["computation_pass"],
                        typicality_score=score,
                        typicality_pass=bool(row["parse_ok"] and threshold is not None and score <= threshold))
            audit_rows.append(item)
        chosen = [r for r in audit_rows if r["task"] == task]
        if chosen:
            for key in ("structured_pass", "provenance_pass", "computation_pass", "typicality_pass"):
                summary["audits"].append(dict(task=task, audit=key, **audit_stats(chosen, key)))
    (RESULTS / "audits.jsonl").write_text("".join(json.dumps(r)+"\n" for r in audit_rows))
    (RESULTS / "typicality_model.json").write_text(json.dumps(typical_metadata, indent=2))
    interventions = read_rows(RESULTS / "interventions.jsonl")
    for task in ("gsm8k", "bbh_boolean"):
        all_rows = [r for r in interventions if r["task"] == task]
        eligible = [r for r in all_rows if r["eligible"]]
        valid = [r for r in eligible if r["valid_answers"]]
        stable = [r for r in valid if r["control_matches_original"]]
        if all_rows:
            summary["interventions"].append(dict(task=task, n_total=len(all_rows),
                eligible=len(eligible), valid=len(valid), stable_control=len(stable),
                unchanged_original=sum(r["unchanged_from_original"] for r in valid),
                unchanged_control=sum(r["unchanged_from_control"] for r in valid),
                unchanged_control_pct=None if not valid else 100*sum(r["unchanged_from_control"] for r in valid)/len(valid),
                unchanged_stable_pct=None if not stable else 100*sum(r["unchanged_from_control"] for r in stable)/len(stable)))
    for path in sorted(RESULTS.glob("ledger_*.jsonl")):
        ledger = read_rows(path)
        if not ledger:
            continue
        n, k = len(ledger), sum(r["success"] for r in ledger)
        relaxed = [[relaxed_json(g["text"]) for g in r["generations"]] for r in ledger]
        diagnostics = dict(
            code_fenced_responses=sum(g["text"].strip().startswith("```") for r in ledger for g in r["generations"]),
            responses=2*n,
            relaxed_parseable_pairs=sum(all(o is not None for o in pair) for pair in relaxed),
            relaxed_correct_pairs=sum(all(o == r["expected"] for o in pair) for r,pair in zip(ledger,relaxed)),
            label="Post-hoc descriptive diagnostic; not a separately pre-registered confidence certificate.")
        summary["ledger"].append(dict(model=ledger[0]["model"], revision=ledger[0]["revision"],
                                      n=n, successes=k, rate=k/n, interval95=cp(k,n),
                                      interval_joint95=cp(k,n,.025),
                                      diagnostics=diagnostics,
                                      failures=[r["id"] for r in ledger if not r["success"]][:8]))
    complete_faith = len(summary["accuracy"]) == 6 and all(x["n"] == 200 for x in summary["accuracy"])
    complete_int = len(interventions) == 400 and len({r["id"] for r in interventions}) == 400
    complete_ledger = len(summary["ledger"]) == 2 and all(r["n"] == 300 for r in summary["ledger"])
    summary["complete"] = complete_faith and complete_int and complete_ledger
    summary["completion"] = dict(faithfulness=complete_faith, interventions=complete_int,
                                 ledger=complete_ledger)
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False))
    # Flattened step table for independent inspection.
    with (RESULTS / "step_table.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["id","task","split","condition","step","name","op","input_references","resolved_inputs","output"])
        for row in rows:
            for step in row["steps"]:
                resolved = []
                for ref in step["refs"]:
                    source = row["atoms"] if ref[0] == "q" else [s["output"] for s in row["steps"][:step["index"]]]
                    index = int(ref[1:])
                    resolved.append(source[index] if index < len(source) else "UNDEFINED")
                writer.writerow([row["id"],row["task"],row["split"],row["condition"],
                                 step["index"],step["name"],step["op"],"|".join(step["refs"]),
                                 json.dumps(resolved),step["output"]])
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    analyze()
