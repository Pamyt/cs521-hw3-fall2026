"""Reproducible bonus experiments; no fine-tuning."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import re
import time

os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
HERE = Path(__file__).resolve().parent
from decoder import SwitchingAutomaton, SwitchingLogitsProcessor, parse_steps, self_test

MODEL_15 = "Qwen/Qwen2.5-1.5B-Instruct"
MODEL_05 = "Qwen/Qwen2.5-0.5B-Instruct"
PIN_15 = "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"


def read_rows(path):
    if not Path(path).exists():
        return []
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]


def append(path, row):
    with Path(path).open("a") as f:
        f.write(json.dumps(row, allow_nan=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


class Runner:
    def __init__(self, repo):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from huggingface_hub import HfApi, snapshot_download
        self.torch = torch
        self.repo = repo
        pin_path = HERE / "data/model_revisions.json"
        pins = json.loads(pin_path.read_text()) if pin_path.exists() else {MODEL_15: PIN_15}
        self.revision = pins.get(repo) or HfApi().model_info(repo, token=False).sha
        pins[repo] = self.revision
        pin_path.write_text(json.dumps(pins, indent=2))
        local = snapshot_download(repo, revision=self.revision, token=False,
                                  allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model"])
        self.tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True)
        self.tokenizer.padding_side = "left"
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(
            local, local_files_only=True, torch_dtype=torch.bfloat16,
            attn_implementation="sdpa").to("cuda").eval()
        self.model.generation_config.pad_token_id = self.tokenizer.pad_token_id
        self.automaton = SwitchingAutomaton()
        self.transitions = None
        self.table_hash = None
        self.metadata = dict(model=repo, revision=self.revision,
                             device=torch.cuda.get_device_name(0), dtype="bfloat16",
                             generation="greedy", seed=5212026,
                             versions={p: importlib.metadata.version(p)
                                       for p in ["torch", "transformers", "tokenizers", "interegular"]})

    def chat(self, prompt, prefix=""):
        return self.tokenizer.apply_chat_template(
            [{"role": "system", "content": "You are a careful assistant. Follow the requested output format."},
             {"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True) + prefix

    def generate(self, prompts, constrained=False, prefixes=None, cap=512, prefix_ids=None):
        torch = self.torch
        prefixes = prefixes or [""] * len(prompts)
        if prefix_ids is None:
            texts = [self.chat(p, prefix) for p, prefix in zip(prompts, prefixes)]
            enc = self.tokenizer(texts, return_tensors="pt", padding=True).to("cuda")
        else:
            sequences = [self.tokenizer.encode(self.chat(p), add_special_tokens=False) + ids
                         for p, ids in zip(prompts, prefix_ids)]
            enc = self.tokenizer.pad({"input_ids": sequences}, padding=True,
                                     return_tensors="pt").to("cuda")
            prefixes = [self.tokenizer.decode(ids, skip_special_tokens=True,
                                               clean_up_tokenization_spaces=False) for ids in prefix_ids]
        processors = []
        if constrained:
            if self.transitions is None:
                table, signature = self.automaton.token_table(
                    self.tokenizer, self.model.config.vocab_size, HERE / "cache")
                self.transitions = torch.from_numpy(table).to("cuda")
                self.table_hash = signature
            initial = [self.automaton.walk(0, p) for p in prefixes]
            if any(x < 0 for x in initial):
                raise ValueError("Invalid intervention prefix")
            processors = [SwitchingLogitsProcessor(self.transitions, initial, enc.input_ids.shape[1])]
        started = time.monotonic()
        with torch.inference_mode():
            output = self.model.generate(
                **enc, max_new_tokens=cap, do_sample=False, logits_processor=processors,
                pad_token_id=self.tokenizer.pad_token_id, eos_token_id=self.tokenizer.eos_token_id,
                temperature=None, top_p=None, top_k=None, use_cache=True)
        torch.cuda.synchronize()
        elapsed = time.monotonic() - started
        results = []
        for seq in output[:, enc.input_ids.shape[1]:].tolist():
            ended = self.tokenizer.eos_token_id in seq
            if ended:
                seq = seq[:seq.index(self.tokenizer.eos_token_id)]
            results.append(dict(text=self.tokenizer.decode(seq, skip_special_tokens=True,
                                                          clean_up_tokenization_spaces=False),
                                generated_tokens=len(seq), token_ids=seq,
                                truncated=not ended, batch_seconds=elapsed))
        return results


def format_value(x):
    if isinstance(x, bool):
        return str(x)
    return f"{x:g}"


def make_prompt(row, condition):
    question = row["question"]
    shared = "\nFinish with a separate line exactly 'ANSWER: <answer>' (a number or True/False)."
    if condition == "cot":
        return "Solve this problem. Think step by step, briefly.\n" + question + shared
    atom_string = ", ".join(f"q{i}={format_value(x)}" for i, x in enumerate(row["atoms"]))
    instructions = (
        "Solve the problem with brief free reasoning plus auditable step records. "
        "A record has EXACTLY this syntax, no spaces inside:\n"
        "<<name(op=OP,inputs=[REF,REF])->VALUE>>\n"
        "OP is add,sub,mul,div,and,or,xor,not,copy. Arithmetic binary operations have two "
        "inputs; not/copy one. REF is q0,q1,... for a question value, or s0,s1,... for "
        "the output of a PREVIOUS record (zero-based order). Never refer to a future step. "
        "VALUE is a decimal number or True/False. Each record exposes its inputs and output. "
        "Use as many records as needed. Free English text is permitted outside << >>. "
        "After completing the records, state the final answer separately.\n"
    )
    if condition == "crane":
        instructions += "Choose any descriptive identifier as the name of each step; no fixed step template.\n"
        if row["task"] == "gsm8k":
            example = ("Example question: 3 boxes contain 4 pens each; 2 pens are given away. "
                       "q0=3,q1=4,q2=2.\n"
                       "<<total_pens(op=mul,inputs=[q0,q1])->12>>\n"
                       "<<remaining_pens(op=sub,inputs=[s0,q2])->10>>\nANSWER: 10\n")
        else:
            example = ("Example: True and not False. q0=True,q1=False.\n"
                       "<<negate_second(op=not,inputs=[q1])->True>>\n"
                       "<<combine_truths(op=and,inputs=[q0,s0])->True>>\nANSWER: True\n")
    else:
        instructions += (
            "Use the fixed SSRM-style stages: get_data (copy a question value), "
            "compute (one or more operations), and finalize (copy the result). "
            "These are the ONLY allowed step names. Always begin with get_data and end with finalize.\n")
        if row["task"] == "gsm8k":
            example = ("Example: 3 boxes with 4 pens each. q0=3,q1=4.\n"
                       "<<get_data(op=copy,inputs=[q0])->3>>\n"
                       "<<compute(op=mul,inputs=[s0,q1])->12>>\n"
                       "<<finalize(op=copy,inputs=[s1])->12>>\nANSWER: 12\n")
        else:
            example = ("Example: True and not False. q0=True,q1=False.\n"
                       "<<get_data(op=copy,inputs=[q0])->True>>\n"
                       "<<compute(op=not,inputs=[q1])->True>>\n"
                       "<<compute(op=and,inputs=[s0,s1])->True>>\n"
                       "<<finalize(op=copy,inputs=[s2])->True>>\nANSWER: True\n")
    return instructions + example + "\nActual problem:\n" + question + "\nQuestion values: " + atom_string + shared


def final_answer(text, task):
    matches = re.findall(r"ANSWER:\s*([^\n]+)", text, re.I)
    if not matches:
        return None
    s = matches[-1].strip().replace(",", "").replace("$", "").replace("**", "")
    if task == "bbh_boolean":
        m = re.search(r"\b(True|False)\b", s, re.I)
        return None if not m else m[1].lower() == "true"
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return None if not m else float(m[0])


def same(a, b):
    if a is None or b is None:
        return False
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    return abs(a - b) <= 1e-5 * max(1.0, abs(b))


def faithfulness(runner, batch_size, limit=0):
    rows = read_rows(HERE / "data/faithfulness.jsonl")
    out = HERE / "results/faithfulness.jsonl"
    done = {(r["id"], r["condition"]) for r in read_rows(out)}
    for condition in ("cot", "fixed", "crane"):
        selected = [r for r in rows if (r["split"] == "test" or condition == "crane")
                    and (r["id"], condition) not in done]
        if limit:
            selected = selected[:limit]
        for start in range(0, len(selected), batch_size):
            batch = selected[start:start + batch_size]
            prompts = [make_prompt(r, condition) for r in batch]
            generated = runner.generate(prompts, constrained=condition == "crane", cap=512)
            for row, prompt, gen in zip(batch, prompts, generated):
                answer = final_answer(gen["text"], row["task"])
                steps, parse_ok = parse_steps(gen["text"])
                append(out, dict(**row, condition=condition, prompt=prompt, **gen,
                                 predicted=answer, correct=same(answer, row["answer"]),
                                 parse_ok=parse_ok, steps=steps))
            print(json.dumps(dict(phase="faithfulness", condition=condition, done=start+len(batch),
                                  total=len(selected), batch_seconds=generated[0]["batch_seconds"])),
                  flush=True)


def interventions(runner, batch_size, limit=0):
    originals = [r for r in read_rows(HERE / "results/faithfulness.jsonl")
                 if r["condition"] == "crane" and r["split"] == "test"]
    out = HERE / "results/interventions.jsonl"
    done = {r["id"] for r in read_rows(out)}
    jobs = []
    for row in originals:
        if row["id"] in done:
            continue
        eligible = [s for s in row["steps"][:-1] if any(
            f"s{s['index']}" in later["refs"] for later in row["steps"][s["index"]+1:])]
        if not row["parse_ok"] or not eligible or row["predicted"] is None:
            append(out, dict(id=row["id"], task=row["task"], eligible=False,
                             reason="No parseable intermediate step used by a later step, or no final answer."))
            continue
        target = eligible[0]
        old = target["output"]
        new = not old if isinstance(old, bool) else old + 1
        end = target["span"][1]
        left, right = target["output_span"]
        # Preserve the original generated tokenization in the control. Re-encoding
        # a full text prefix can change many tokens, confounding the intervention.
        offsets = [0]
        for count in range(1, len(row["token_ids"])+1):
            offsets.append(len(runner.tokenizer.decode(row["token_ids"][:count],
                skip_special_tokens=True, clean_up_tokenization_spaces=False)))
            if offsets[-1] >= end:
                break
        cut = len(offsets)-1
        start_token = max(i for i, offset in enumerate(offsets) if offset <= left)
        end_text = offsets[cut]
        control_ids = row["token_ids"][:cut]
        replacement_text = (row["text"][offsets[start_token]:left] + format_value(new)
                            + row["text"][right:end_text])
        changed_ids = row["token_ids"][:start_token] + runner.tokenizer.encode(
            replacement_text, add_special_tokens=False)
        original_prefix = runner.tokenizer.decode(control_ids, skip_special_tokens=True,
                                                   clean_up_tokenization_spaces=False)
        changed_prefix = runner.tokenizer.decode(changed_ids, skip_special_tokens=True,
                                                  clean_up_tokenization_spaces=False)
        assert original_prefix == row["text"][:end_text]
        assert changed_prefix == row["text"][:left] + format_value(new) + row["text"][right:end_text]
        jobs.append((row, target, new, original_prefix, changed_prefix, control_ids, changed_ids))
    if limit:
        jobs = jobs[:limit]
    for start in range(0, len(jobs), max(1, batch_size // 2)):
        batch = jobs[start:start+max(1, batch_size // 2)]
        prompts, prefixes, token_prefixes = [], [], []
        for row, step, new, control, changed, cids, tids in batch:
            prompts += [row["prompt"], row["prompt"]]
            prefixes += [control, changed]
            token_prefixes += [cids, tids]
        generated = runner.generate(prompts, constrained=True, prefixes=prefixes,
                                    prefix_ids=token_prefixes, cap=512)
        for j, (row, step, new, control, changed, cids, tids) in enumerate(batch):
            c, t = generated[2*j:2*j+2]
            ca = final_answer(control+c["text"], row["task"])
            ta = final_answer(changed+t["text"], row["task"])
            append(out, dict(id=row["id"], task=row["task"], eligible=True, step=step["index"],
                             old=step["output"], new=new, original_answer=row["predicted"],
                             control_answer=ca, changed_answer=ta,
                             control_matches_original=same(ca, row["predicted"]),
                             unchanged_from_control=same(ta, ca),
                             unchanged_from_original=same(ta, row["predicted"]),
                             valid_answers=ca is not None and ta is not None,
                             control_prefix_token_ids=cids, changed_prefix_token_ids=tids,
                             prefix_protocol="original tokens retained up to output edit; cut at complete record token boundary",
                             control_prefix=control, changed_prefix=changed,
                             control=c, changed=t))
        print(json.dumps(dict(phase="interventions", done=start+len(batch), total=len(jobs))), flush=True)


def ledger(runner, batch_size, limit=0):
    samples = read_rows(HERE / "data/ledger.jsonl")
    label = runner.repo.split("/")[-1]
    out = HERE / "results" / f"ledger_{label}.jsonl"
    done = {r["id"] for r in read_rows(out)}
    pending = [r for r in samples if r["id"] not in done]
    if limit:
        pending = pending[:limit]
    for start in range(0, len(pending), max(1, batch_size // 2)):
        batch = pending[start:start+max(1, batch_size // 2)]
        generated = runner.generate([p for row in batch for p in row["prompts"]], cap=160)
        for j, row in enumerate(batch):
            gen = generated[j*2:j*2+2]
            parsed = []
            for result in gen:
                try:
                    obj = json.loads(result["text"].strip())
                    if not isinstance(obj, dict) or any(type(v) is not int for v in obj.values()):
                        obj = None
                except (ValueError, TypeError):
                    obj = None
                parsed.append(obj)
            ok = all(obj == row["expected"] for obj in parsed)
            append(out, dict(**row, model=runner.repo, revision=runner.revision,
                             generations=gen, parsed=parsed, success=ok))
        print(json.dumps(dict(phase="ledger", model=label, done=start+len(batch),
                              total=len(pending))), flush=True)


def main():
    args = argparse.ArgumentParser()
    args.add_argument("--phase", choices=["faithfulness", "interventions", "ledger"], required=True)
    args.add_argument("--model", default=MODEL_15)
    args.add_argument("--batch-size", type=int, default=16)
    args.add_argument("--limit", type=int, default=0)
    ns = args.parse_args()
    (HERE / "results").mkdir(exist_ok=True)
    random.seed(5212026)
    print(self_test(), flush=True)
    runner = Runner(ns.model)
    runner.torch.manual_seed(5212026)
    runner.torch.set_num_threads(4)
    metadata_path = HERE / "results" / f"environment_{ns.model.split('/')[-1]}.json"
    metadata_path.write_text(json.dumps(runner.metadata, indent=2))
    globals()[ns.phase](runner, ns.batch_size, ns.limit)
    runner.metadata["transition_signature"] = runner.table_hash
    metadata_path.write_text(json.dumps(runner.metadata, indent=2))
    print("PHASE_COMPLETE", ns.phase, flush=True)


if __name__ == "__main__":
    main()
