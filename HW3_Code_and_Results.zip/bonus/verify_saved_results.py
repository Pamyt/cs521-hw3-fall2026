"""Recompute HW3 bonus statistics from its saved records only."""
import json
from pathlib import Path
import numpy as np
from scipy.stats import fisher_exact
from analysis_helpers import structured_audit,Typicality,audit_stats
from decoder import parse_steps
from experiments import final_answer,same

ROOT=Path(__file__).resolve().parent
R=ROOT/"results"
def read(name):
    return [json.loads(x) for x in (R/name).read_text().splitlines() if x.strip()]
summary=json.loads((R/"summary.json").read_text())
rows=read("faithfulness.jsonl")
assert len(rows)==1300 and len({(r["id"],r["condition"]) for r in rows})==1300
for row in rows:
    predicted=final_answer(row["text"],row["task"])
    assert same(predicted,row["predicted"]) or (predicted is None and row["predicted"] is None)
    assert row["correct"]==same(predicted,row["answer"])
    steps,parsed=parse_steps(row["text"])
    assert steps==row["steps"] and parsed==row["parse_ok"]
for record in summary["accuracy"]:
    chosen=[r for r in rows if r["task"]==record["task"] and
            r["condition"]==record["condition"] and r["split"]=="test"]
    assert len(chosen)==record["n"]==200
    assert sum(r["correct"] for r in chosen)==record["correct"]
    assert abs(record["accuracy"]-100*sum(r["correct"] for r in chosen)/200)<1e-10
    assert abs(record["parse_pct"]-100*sum(r["parse_ok"] for r in chosen)/200)<1e-10
assert len(summary["accuracy"])==6
saved_audits={r["id"]:r for r in read("audits.jsonl")}
assert len(saved_audits)==400
for task in ["gsm8k","bbh_boolean"]:
    dev=[r for r in rows if r["task"]==task and r["condition"]=="crane" and
         r["split"]=="dev" and r["parse_ok"]]
    model=Typicality(dev[:25])
    threshold=None if not dev[25:] else float(np.quantile([model.score(r) for r in dev[25:]],.95,method="higher"))
    checked=[]
    for row in [r for r in rows if r["task"]==task and r["condition"]=="crane" and r["split"]=="test"]:
        audit=structured_audit(row);score=model.score(row)
        saved=saved_audits[row["id"]]
        assert audit==saved["audit"]
        assert abs(score-saved["typicality_score"])<1e-12
        assert saved["typicality_pass"]==bool(row["parse_ok"] and threshold is not None and score<=threshold)
        checked.append(saved)
    for record in [r for r in summary["audits"] if r["task"]==task]:
        fresh=audit_stats(checked,record["audit"])
        for key,value in fresh.items():
            if isinstance(value,float):assert abs(value-record[key])<1e-10,key
            else:assert value==record[key],key
        assert abs(fisher_exact(record["contingency"]).pvalue-record["fisher_p"])<1e-12
interventions=read("interventions.jsonl")
assert len(interventions)==400 and len({r["id"] for r in interventions})==400
original={r["id"]:r for r in rows if r["condition"]=="crane" and r["split"]=="test"}
for row in interventions:
    if not row["eligible"]:continue
    ids=row["control_prefix_token_ids"]
    assert ids==original[row["id"]]["token_ids"][:len(ids)]
    assert row["valid_answers"]==(row["control_answer"] is not None and row["changed_answer"] is not None)
    assert row["unchanged_from_control"]==same(row["control_answer"],row["changed_answer"])
    assert row["control_matches_original"]==same(row["control_answer"],row["original_answer"])
for record in summary["interventions"]:
    chosen=[r for r in interventions if r["task"]==record["task"]]
    eligible=[r for r in chosen if r["eligible"]]
    valid=[r for r in eligible if r["valid_answers"]]
    stable=[r for r in valid if r["control_matches_original"]]
    assert [len(chosen),len(eligible),len(valid),len(stable)]==[record[k] for k in ["n_total","eligible","valid","stable_control"]]
    assert record["unchanged_control"]==sum(r["unchanged_from_control"] for r in valid)
    assert abs(record["unchanged_control_pct"]-100*sum(r["unchanged_from_control"] for r in valid)/len(valid))<1e-10
    assert abs(record["unchanged_stable_pct"]-100*sum(r["unchanged_from_control"] for r in stable)/len(stable))<1e-10
result=dict(assignment="HW3",verified=True,reasoning_records=1300,
            cases_per_condition=400,audit_records=400,intervention_records=400,
            eligible_interventions=sum(r["eligible"] for r in interventions),
            stable_controls=sum(r.get("control_matches_original",False) and r.get("valid_answers",False) for r in interventions),
            no_training_or_inference_rerun=True)
(R/"assignment_verification.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
