HW3 bonus evidence only

The report, inputs and experimental results belong to this assignment.
The common model runner is retained unchanged, but the notebook selects only
this assignment's phases. No results for the other homework are embedded.

Run python verify_saved_results.py to recompute the saved statistics.
This needs NumPy and SciPy and does not train or download any model.
analysis_helpers.py supplies pure analysis functions; its legacy analyze()
entry point is not the assignment-specific verification command.
Optional inference needs PyTorch, transformers 4.53.2, accelerate 1.15.0,
and interegular 0.3.3 on a suitable CUDA GPU. Pinned model revisions are saved.
New outputs must go into a separate reproduction directory.
