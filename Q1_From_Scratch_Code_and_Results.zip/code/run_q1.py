"""Fresh five-epoch Q1 experiment with resumable per-epoch checkpoints."""
import argparse
import hashlib
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import q3_multinorm as s

def now():return datetime.now(timezone.utc).isoformat()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save_json(path,value):
    tmp=path.with_suffix('.json.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def natural_loss(model,x,y):
    model.train();return F.cross_entropy(model(x),y)
def adversarial_loss(model,x,y):
    model.eval();adv=s.pgd_linf(model,x,y,8/255,2/255,10,True)
    model.train();return F.cross_entropy(model(adv),y)

def train(name,dest):
    torch.manual_seed(0)
    model=s.make_model()
    opt=torch.optim.SGD(model.parameters(),lr=.01,momentum=.9,weight_decay=5e-4)
    sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,5*(len(s.y_train)//128))
    torch.manual_seed(0)  # Match the official adv_train loop's RNG reset.
    checkpoint=dest/'training_checkpoint.pt';history=[]
    gpu_api=getattr(torch,s.device.type,None)
    if checkpoint.exists():
        state=torch.load(checkpoint,map_location='cpu',weights_only=True)
        model.load_state_dict(state['model']);opt.load_state_dict(state['optimizer']);sched.load_state_dict(state['scheduler'])
        torch.set_rng_state(state['cpu_rng'])
        if state.get('gpu_rng') is not None:gpu_api.set_rng_state(state['gpu_rng'])
        history=state['history'];print('RESUME',name,len(history),flush=True)
    loss_fn=natural_loss if name=='standard' else adversarial_loss
    for epoch in range(len(history),5):
        s.sync_device();started=time.perf_counter();losses=[]
        for x,y in s.batches(s.x_train,s.y_train,128,shuffle=True):
            if len(y)<128:continue
            x=s.augment(x);loss=loss_fn(model,x,y)
            opt.zero_grad();loss.backward();opt.step();sched.step();losses.append(loss.item())
        s.sync_device();history.append(dict(epoch=epoch+1,loss=float(np.mean(losses)),seconds=time.perf_counter()-started,completed_at=now()))
        state=dict(model={k:v.detach().cpu() for k,v in model.state_dict().items()},optimizer=opt.state_dict(),scheduler=sched.state_dict(),history=history,cpu_rng=torch.get_rng_state(),gpu_rng=gpu_api.get_rng_state() if s.device.type in ['cuda','mps'] else None)
        tmp=dest/'training_checkpoint.pt.tmp';torch.save(state,tmp);tmp.replace(checkpoint)
        save_json(dest/'training_history.json',history)
        print('EPOCH',name,json.dumps(history[-1]),flush=True)
    s.save_model(model,dest/'model.pt');return model.eval()

def evaluate(model,dest):
    out=dest/'evaluation.json';records=json.loads(out.read_text()) if out.exists() else []
    for radius in [0,2,4,8,12]:
        if any(r['epsilon_over_255']==radius for r in records):continue
        torch.manual_seed(42);counts=dict(clean=0,fgsm=0,pgd=0);per_example=[]
        s.sync_device();started=time.perf_counter()
        for start in range(0,len(s.y_test),100):
            x,y=s.x_test[start:start+100],s.y_test[start:start+100]
            with torch.no_grad():clean=model(x).argmax(1).eq(y)
            if radius==0:fgsm,pgd=clean.clone(),clean.clone()
            else:
                eps=radius/255
                fx=s.pgd_linf(model,x,y,eps,eps,1,False)
                with torch.no_grad():fgsm=clean & model(fx).argmax(1).eq(y)
                pgd=fgsm.clone()
                for _ in range(2):
                    ax=s.pgd_linf(model,x,y,eps,eps/4,50,True)
                    with torch.no_grad():pgd &= model(ax).argmax(1).eq(y)
            masks={k:v.cpu().tolist() for k,v in dict(clean=clean,fgsm=fgsm,pgd=pgd).items()}
            for k,v in masks.items():counts[k]+=sum(v)
            per_example.extend(dict(test_index=start+i,**{k:bool(v[i]) for k,v in masks.items()}) for i in range(len(y)))
        s.sync_device();row=dict(epsilon_over_255=radius,counts=counts,n_test=len(s.y_test),accuracy_percent={k:100*v/len(s.y_test) for k,v in counts.items()},elapsed_seconds=time.perf_counter()-started,per_example=per_example)
        records.append(row);save_json(out,records);print('EVALUATION',dest.name,radius,row['accuracy_percent'],flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--data-dir',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('results'));a=p.parse_args()
    torch.set_num_threads(4);s.DATA_DIR=a.data_dir;s.initialize_data()
    assert len(s.y_train)==10000 and len(s.y_test)==1000
    a.output.mkdir(exist_ok=True,parents=True)
    protocol=dict(started_at=now(),epochs=5,seed=0,architecture='Official Q3 width-32 PreActResNet18 with ReLU and input normalization',initialization='Each model starts from seed 0 and make_model; no base or pretrained model is loaded. Interrupted runs resume only their own epoch checkpoint.',optimizer='SGD',learning_rate=.01,momentum=.9,weight_decay=5e-4,batch_size=128,drop_last=True,scheduler='CosineAnnealingLR over 5 * floor(10000/128) steps',augmentation='Official random crop padding 4 and horizontal flip',train_size=10000,test_size=1000,training_attack=dict(norm='linf',epsilon=8/255,steps=10,step_size=2/255,random_start=True),evaluation=dict(radii_over_255=[0,2,4,8,12],pgd_steps=50,restarts=2,step_size='epsilon/4',robust_rule='clean-correct and correct on FGSM plus both PGD endpoint candidates'),device=str(s.device),torch=torch.__version__,numpy=np.__version__,platform=platform.platform(),data_sha256={n:digest(a.data_dir/n) for n in ['cifar10_train_10k.pt','cifar10_test_1k.pt']},source_sha256={n:digest(Path(__file__).parent/n) for n in ['run_q1.py','q3_multinorm.py']})
    f=a.output/'protocol.json'
    if f.exists():assert json.loads(f.read_text())['source_sha256']==protocol['source_sha256']
    else:save_json(f,protocol)
    for name in ['standard','linf']:
        d=a.output/name;d.mkdir(exist_ok=True)
        model=train(name,d);evaluate(model,d);del model
        if s.device.type=='mps':torch.mps.empty_cache()
    save_json(a.output/'completed.json',dict(completed_at=now()));print('COMPLETE',flush=True)
if __name__=='__main__':main()
