"""CS521 HW3 Q3: completed scaffold and reproducible experiment runner.
Adapted from the official nalinwadhwa02/CCS521FA26HW notebook.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device(os.environ.get("CS521_DEVICE", "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")))
print("device:", device)

NORMS = ("linf", "l2", "l1")
EPS = {"linf": 8 / 255, "l2": 0.5, "l1": 12.0}

def load_data(path):
    # The files store images as uint8. Convert them to floats in [0, 1] on the GPU.
    x, y = torch.load(DATA_DIR / path, map_location="cpu", weights_only=True)
    return x.float().div(255).to(device), y.to(device)


# Training data: 10,000 images. Test data: the first 1,000 CIFAR-10 test images.
def initialize_data():
    global x_train, y_train, x_test, y_test
    x_train, y_train = load_data("cifar10_train_10k.pt")
    x_test, y_test = load_data("cifar10_test_1k.pt")
    print("train:", tuple(x_train.shape), "test:", tuple(x_test.shape), flush=True)


def augment(x):
    # Random horizontal flip and random crop (padding 4) for each image.
    n = x.shape[0]
    flip = torch.rand(n, device=x.device) < 0.5
    x = torch.where(flip.view(-1, 1, 1, 1), x.flip(3), x)
    padded = F.pad(x, (4, 4, 4, 4))
    i = torch.randint(0, 9, (n, 1, 1), device=x.device) + torch.arange(32, device=x.device).view(1, 32, 1)
    j = torch.randint(0, 9, (n, 1, 1), device=x.device) + torch.arange(32, device=x.device).view(1, 1, 32)
    return padded[torch.arange(n, device=x.device).view(n, 1, 1), :, i, j].permute(0, 3, 1, 2).contiguous()


def batches(x, y, batch_size, shuffle):
    idx = torch.randperm(len(x), device=x.device) if shuffle else torch.arange(len(x), device=x.device)
    for k in range(0, len(x), batch_size):
        j = idx[k:k + batch_size]
        yield x[j], y[j]

# PreActResNet-18 with half width (2.8M parameters). The input is an image in [0, 1].
class PreActBlock(nn.Module):
    def __init__(self, in_planes, planes, stride):
        super().__init__()
        self.bn1 = nn.BatchNorm2d(in_planes)
        self.conv1 = nn.Conv2d(in_planes, planes, 3, stride, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, 3, 1, 1, bias=False)
        self.shortcut = None
        if stride != 1 or in_planes != planes:
            self.shortcut = nn.Conv2d(in_planes, planes, 1, stride, bias=False)

    def forward(self, x):
        out = F.relu(self.bn1(x))
        shortcut = self.shortcut(out) if self.shortcut is not None else x
        out = self.conv1(out)
        out = self.conv2(F.relu(self.bn2(out)))
        return out + shortcut


class PreActResNet18(nn.Module):
    def __init__(self, width=32, num_classes=10):
        super().__init__()
        self.register_buffer("mean", torch.tensor([0.4914, 0.4822, 0.4465]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.2471, 0.2435, 0.2616]).view(1, 3, 1, 1))
        self.conv1 = nn.Conv2d(3, width, 3, 1, 1, bias=False)
        layers, in_planes = [], width
        for mult, stride in [(1, 1), (1, 1), (2, 2), (2, 1), (4, 2), (4, 1), (8, 2), (8, 1)]:
            layers.append(PreActBlock(in_planes, mult * width, stride))
            in_planes = mult * width
        self.layers = nn.Sequential(*layers)
        self.bn = nn.BatchNorm2d(in_planes)
        self.linear = nn.Linear(in_planes, num_classes)

    def forward(self, x):
        out = self.layers(self.conv1((x - self.mean) / self.std))
        out = F.adaptive_avg_pool2d(F.relu(self.bn(out)), 1).flatten(1)
        return self.linear(out)


def make_model():
    return PreActResNet18().to(device)


def load_base_model():
    model = make_model()
    model.load_state_dict(torch.load(DATA_DIR / "linf_base.pt", map_location=device, weights_only=True))
    return model

def clip_box(x, delta):
    # Make x + delta an image in [0, 1]. This never increases |delta_i|.
    return (x + delta).clamp(0, 1) - x


def input_grad(model, x, delta, y):
    delta = delta.detach().requires_grad_(True)
    loss = F.cross_entropy(model(x + delta), y, reduction="sum")
    (grad,) = torch.autograd.grad(loss, delta)
    return grad.detach()


def l2_norm(v):
    return v.flatten(1).norm(dim=1).view(-1, 1, 1, 1)


def pgd_linf(model, x, y, eps, alpha, steps, rand_init=True):
    delta = torch.empty_like(x).uniform_(-eps, eps) if rand_init else torch.zeros_like(x)
    delta = clip_box(x, delta)
    for _ in range(steps):
        grad = input_grad(model, x, delta, y)
        delta = clip_box(x, (delta + alpha * grad.sign()).clamp(-eps, eps))
    return (x + delta).detach()

def pgd_l2(model, x, y, eps, alpha, steps, rand_init=True):
    delta = torch.zeros_like(x)
    if rand_init:
        delta = torch.randn_like(x)
        # Uniform radius, matching the random-radius convention of the supplied L1 attack.
        r = torch.rand(x.shape[0], 1, 1, 1, device=x.device)
        delta = delta / l2_norm(delta).clamp_min(1e-12) * (eps * r)
    delta = clip_box(x, delta)
    for _ in range(steps):
        grad = input_grad(model, x, delta, y)
        delta = delta + alpha * grad / l2_norm(grad).clamp_min(1e-12)
        delta = delta * (eps / l2_norm(delta).clamp_min(1e-12)).clamp(max=1.0)
        delta = clip_box(x, delta)
    return (x + delta).detach()


def project_l1(delta, eps):
    # Projection of each image of delta onto the L1 ball of radius eps (Duchi et al., 2008).
    v = delta.flatten(1)
    a = v.abs()
    outside = a.sum(dim=1) > eps
    if not outside.any():
        return delta
    mu, _ = a.sort(dim=1, descending=True)
    cumsum = mu.cumsum(dim=1)
    idx = torch.arange(1, v.shape[1] + 1, device=v.device, dtype=v.dtype)
    rho = ((mu - (cumsum - eps) / idx > 0) * idx).argmax(dim=1, keepdim=True)
    theta = (cumsum.gather(1, rho) - eps) / (rho + 1).to(v.dtype)
    w = (a - theta).clamp_min(0) * v.sign()
    return torch.where(outside.unsqueeze(1), w, v).view(delta.shape)


def pgd_l1(model, x, y, eps, alpha, steps, rand_init=True, k=20):
    # Each step changes only the k coordinates with the largest gradient.
    # Coordinates at the image boundary that point outward are skipped.
    delta = torch.zeros_like(x)
    if rand_init:
        delta = torch.distributions.Laplace(0.0, 1.0).sample(x.shape).to(x.device)
        r = torch.rand(x.shape[0], 1, 1, 1, device=x.device)
        delta = delta / delta.flatten(1).abs().sum(1).view(-1, 1, 1, 1) * eps * r
    delta = clip_box(x, delta)
    for _ in range(steps):
        grad = input_grad(model, x, delta, y).flatten(1)
        x_cur = (x + delta).flatten(1)
        blocked = ((grad > 0) & (x_cur >= 1)) | ((grad < 0) & (x_cur <= 0))
        grad = grad.masked_fill(blocked, 0)
        top = grad.abs().topk(k, dim=1).indices
        step = torch.zeros_like(grad).scatter(1, top, grad.gather(1, top).sign())
        delta = clip_box(x, delta + alpha * (step / k).view_as(x))
        delta = project_l1(delta, eps)
    return (x + delta).detach()


ATTACKS = {"linf": pgd_linf, "l2": pgd_l2, "l1": pgd_l1}


def attack(model, x, y, norm, steps=10):
    # The attack for one norm with the default eps and step size.
    alpha = EPS["l1"] / steps ** 0.5 if norm == "l1" else 2.5 * EPS[norm] / steps
    return ATTACKS[norm](model, x, y, EPS[norm], alpha, steps)

def test_model(model, steps=50, restarts=2, batch_size=250):
    model.eval()
    torch.manual_seed(0)  # the same random starts of the attacks for each model, so the results are comparable
    start = time.time()
    correct = {k: 0 for k in ("clean", *NORMS, "union")}
    for i in range(0, len(x_test), batch_size):
        x, y = x_test[i:i + batch_size], y_test[i:i + batch_size]
        with torch.no_grad():
            clean = model(x).argmax(1) == y
        union = clean.clone()
        for norm in NORMS:
            robust = clean.clone()
            for _ in range(restarts):
                x_adv = attack(model, x, y, norm, steps)
                with torch.no_grad():
                    robust &= model(x_adv).argmax(1) == y
            correct[norm] += robust.sum().item()
            union &= robust
        correct["clean"] += clean.sum().item()
        correct["union"] += union.sum().item()
    acc = {k: 100.0 * v / len(y_test) for k, v in correct.items()}
    print("  ".join(f"{k} {v:.1f}" for k, v in acc.items()) + f"   ({time.time() - start:.0f} s)")
    return acc

def adv_train(model, loss_fn, epochs=10, lr=0.01, batch_size=128, gp_beta=None, seed=0, **kwargs):
    torch.manual_seed(seed)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs * (len(x_train) // batch_size))
    params = list(model.parameters())
    start = time.time()
    history = []
    for epoch in range(epochs):
        sync_device()
        epoch_start = time.perf_counter()
        losses = []
        for x, y in batches(x_train, y_train, batch_size, shuffle=True):
            if len(y) < batch_size:  # skip the last, smaller batch
                continue
            x = augment(x)
            loss = loss_fn(model, x, y, **kwargs)
            opt.zero_grad()
            if gp_beta is None:
                loss.backward()
            else:
                # RAMP (part (b)): combine the adversarial gradient g_a and the natural gradient g_n
                # for each parameter tensor. gradient_projection is defined in part (b).
                g_a = torch.autograd.grad(loss, params)
                g_n = torch.autograd.grad(F.cross_entropy(model(x), y), params)
                for p, ga, gn in zip(params, g_a, g_n):
                    p.grad = gp_beta * gradient_projection(gn, ga) + (1 - gp_beta) * ga
            opt.step()
            sched.step()
            losses.append(loss.item())
        sync_device()
        history.append({"epoch": epoch + 1, "loss": float(np.mean(losses)), "seconds": time.perf_counter() - epoch_start})
        print(json.dumps(history[-1]), flush=True)
    model.eval()
    model.training_history = history
    return model

def single_norm_loss(model, x, y, norm):
    model.eval()
    x_adv = attack(model, x, y, norm)
    model.train()
    return F.cross_entropy(model(x_adv), y)


def ramp_loss(model, x, y, lam=0.5):
    model.eval()
    x_q = attack(model, x, y, "linf")
    x_r = attack(model, x, y, "l1")
    model.train()
    logits_q, logits_r = model(x_q), model(x_r)
    ce_q = F.cross_entropy(logits_q, y, reduction="none")
    ce_r = F.cross_entropy(logits_r, y, reduction="none")
    # PyTorch's target is p_q, input is log p_r: this is KL(p_q || p_r).
    kl = F.kl_div(F.log_softmax(logits_r, dim=1), F.softmax(logits_q, dim=1),
                  reduction="none").sum(dim=1)
    mask = (logits_q.argmax(1) == y).to(kl.dtype)
    # Mean over the qualifying examples; exactly zero when none qualify.
    paired = (kl * mask).sum() / mask.sum().clamp_min(1)
    return torch.maximum(ce_q, ce_r).mean() + lam * paired

def gradient_projection(g_n, g_a):
    cosine = (g_n.flatten() @ g_a.flatten()) / (g_n.norm() * g_a.norm()).clamp_min(1e-12)
    return cosine.clamp_min(0) * g_n


class AlternatingDistillationLoss:
    """Alternate L1/L2 updates while retaining an L-infinity-robust teacher.

    This is a student-method candidate, not a claim of global research novelty.
    Teacher targets never depend on test examples or test labels.
    """
    def __init__(self, teacher, distill_weight=0.5, clean_weight=0.25):
        self.teacher = teacher.eval()
        for p in self.teacher.parameters():
            p.requires_grad_(False)
        self.distill_weight = distill_weight
        self.clean_weight = clean_weight
        self.batch_index = 0
        self.stats = []

    def __call__(self, model, x, y):
        norm = ("l1", "l2")[self.batch_index % 2]
        self.batch_index += 1
        model.eval()
        x_alt = attack(model, x, y, norm)
        # Keep attack cost identical in the ablation to isolate distillation.
        x_anchor = attack(model, x, y, "linf")
        with torch.no_grad():
            teacher_logits = self.teacher(x)
            teacher_prob = F.softmax(teacher_logits, dim=1)
            reliable = (teacher_logits.argmax(1) == y)
        model.train()
        alt_logits = model(x_alt)
        anchor_logits = model(x_anchor)
        clean_logits = model(x)
        ce_alt = F.cross_entropy(alt_logits, y)
        ce_clean = F.cross_entropy(clean_logits, y)
        kd_each = F.kl_div(F.log_softmax(anchor_logits, dim=1), teacher_prob,
                          reduction="none").sum(dim=1)
        mask = reliable.to(kd_each.dtype)
        kd = (kd_each * mask).sum() / mask.sum().clamp_min(1)
        loss = ce_alt + self.distill_weight * kd + self.clean_weight * ce_clean
        self.stats.append({"norm": norm, "ce_alt": ce_alt.detach().item(),
                           "clean_ce": ce_clean.detach().item(), "distillation": kd.detach().item(),
                           "teacher_correct_fraction": mask.mean().item()})
        return loss

_my_loss_instance = None
def my_loss(model, x, y):
    global _my_loss_instance
    if _my_loss_instance is None:
        _my_loss_instance = AlternatingDistillationLoss(load_base_model())
    return _my_loss_instance(model, x, y)



def sync_device():
    if device.type == "cuda": torch.cuda.synchronize()
    elif device.type == "mps": torch.mps.synchronize()

def save_model(model, path):
    torch.save({k: v.detach().cpu() for k, v in model.state_dict().items()}, path)

def execute_run(method, seed, epochs=10):
    dest = ROOT / "results/q3" / f"{method}_seed{seed}_epochs{epochs}"
    dest.mkdir(parents=True, exist_ok=True)
    result_path = dest / "result.json"
    if result_path.exists():
        print("SKIP_COMPLETE", dest.name, flush=True)
        return json.loads(result_path.read_text())
    torch.manual_seed(seed)
    model = load_base_model()
    loss_fn = None
    extra = {}
    if method in NORMS:
        loss_fn = single_norm_loss
        extra["norm"] = method
    elif method == "ramp":
        loss_fn = ramp_loss
        extra["gp_beta"] = 0.5
    elif method in ["alternating_distillation", "without_distillation"]:
        loss_fn = AlternatingDistillationLoss(load_base_model(),
                    distill_weight=0.5 if method == "alternating_distillation" else 0.0)
    elif method != "base":
        raise ValueError(method)
    if loss_fn is not None:
        model = adv_train(model, loss_fn, epochs=epochs, seed=seed, **extra)
        save_model(model, dest / "model.pt")
        (dest / "training_history.json").write_text(json.dumps(model.training_history, indent=2) + "\n")
        if isinstance(loss_fn, AlternatingDistillationLoss):
            (dest / "batch_statistics.json").write_text(json.dumps(loss_fn.stats) + "\n")
    sync_device()
    start = time.perf_counter()
    acc = test_model(model)  # Required 1,000 examples, 50 steps, two restarts.
    sync_device()
    result = {"method": method, "seed": seed, "epochs": epochs if method != "base" else 0,
              "accuracy_percent": acc, "evaluation_seconds": time.perf_counter() - start,
              "training_history": getattr(model, "training_history", []),
              "evaluation": {"n": 1000, "steps": 50, "restarts": 2, "batch_size": 250},
              "device": str(device), "torch": torch.__version__,
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    print("RUN_COMPLETE", method, seed, json.dumps(acc), flush=True)
    del model, loss_fn
    if device.type == "cuda": torch.cuda.empty_cache()
    elif device.type == "mps": torch.mps.empty_cache()
    return result

def benchmark():
    model = load_base_model()
    model.eval()
    x, y = x_train[:128], y_train[:128]
    for norm in NORMS:
        sync_device()
        start = time.perf_counter()
        x_adv = attack(model, x, y, norm, steps=10)
        sync_device()
        print("BENCHMARK", norm, time.perf_counter() - start, flush=True)
        delta = x_adv - x
        ord_value = {"linf": float("inf"), "l2": 2, "l1": 1}[norm]
        max_norm = delta.flatten(1).norm(p=ord_value, dim=1).max().item()
        assert max_norm <= EPS[norm] + 1e-4, (norm, max_norm)
        assert x_adv.min() >= 0 and x_adv.max() <= 1
        assert not model.training

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--method", default="benchmark", choices=["benchmark","base",*NORMS,"ramp","alternating_distillation","without_distillation","all","strong"])
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--checkpoint")
    a = p.parse_args()
    torch.set_num_threads(4)
    initialize_data()
    if a.method == "benchmark":
        benchmark()
    elif a.method == "all":
        schedule = [("base",0),("linf",0),("l2",0),("l1",0),("ramp",0),("ramp",1),
                    ("alternating_distillation",0),("alternating_distillation",1),
                    ("without_distillation",0),("without_distillation",1)]
        for method, seed in schedule: execute_run(method, seed)
    elif a.method == "strong":
        if not a.checkpoint: raise ValueError("--checkpoint is required")
        model = make_model()
        model.load_state_dict(torch.load(a.checkpoint, map_location=device, weights_only=True))
        acc = test_model(model, steps=200, restarts=5)
        Path(a.checkpoint).with_name("strong_evaluation.json").write_text(
            json.dumps({"accuracy_percent": acc, "steps":200, "restarts":5, "n":1000}, indent=2) + "\n")
    else:
        execute_run(a.method, a.seed, a.epochs)

if __name__ == "__main__":
    main()
