CS521 HW3 Q1 — five-epoch training from scratch.
Source adapted from the official Q3 scaffold. Public data download and execution are provided in Q1_From_Scratch.ipynb. Model weights and public datasets are excluded from this compact archive. Every reported count is supported by per-example outcomes.
